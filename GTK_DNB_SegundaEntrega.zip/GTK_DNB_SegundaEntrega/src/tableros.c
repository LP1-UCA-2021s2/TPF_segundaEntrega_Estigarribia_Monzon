/*
 * tableros.c
 *
 *  Created on: 28 oct. 2021
 *      Author: lp1-2021
 */
/*int tablero3[5][5];
int tablero4[7][7];
int tablero5[9][9];
int tablero6[11][11];
int tablero7[13][13];
int tablero8[15][15];
int tablero9[17][17];
int tablero10[19][19];
int tablero11[21][21];
int tablero12[23][23];
int tablero13[25][25];
int tablero14[27][27];
int tablero15[29][29];*/
